/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.conjunto.hojassecas;

public class Multa {
    private String idMulta;
    private String fechaMulta;
    private String propiedad;
    private String persona;
    private String descripcion;
    private double valorMulta;
    private String fechaMaximaPago;

    // Constructor
    public Multa(String idMulta, String fechaMulta, String propiedad, String persona,
                 String descripcion, double valorMulta, String fechaMaximaPago) {
        this.idMulta = idMulta;
        this.fechaMulta = fechaMulta;
        this.propiedad = propiedad;
        this.persona = persona;
        this.descripcion = descripcion;
        this.valorMulta = valorMulta;
        this.fechaMaximaPago = fechaMaximaPago;
    }

    // Método para verificar si hay multas
    public static String verificarMultas(String numeroFactura) {
        // Aquí deberías implementar la lógica para verificar si hay multas
        // asociadas a la factura. Este es solo un ejemplo simulado.

        // Simulando la verificación de multas
        boolean tieneMulta = false; // Cambiar a true si hay multas

        if (tieneMulta) {
            return "El propietario tiene multas pendientes.";
        } else {
            return "El propietario no tiene multas pendientes.";
        }
    }

    // Getters y Setters (si son necesarios)

    public String getIdMulta() {
        return idMulta;
    }

    public void setIdMulta(String idMulta) {
        this.idMulta = idMulta;
    }

    public String getFechaMulta() {
        return fechaMulta;
    }

    public void setFechaMulta(String fechaMulta) {
        this.fechaMulta = fechaMulta;
    }

    public String getPropiedad() {
        return propiedad;
    }

    public void setPropiedad(String propiedad) {
        this.propiedad = propiedad;
    }

    public String getPersona() {
        return persona;
    }

    public void setPersona(String persona) {
        this.persona = persona;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getValorMulta() {
        return valorMulta;
    }

    public void setValorMulta(double valorMulta) {
        this.valorMulta = valorMulta;
    }

    public String getFechaMaximaPago() {
        return fechaMaximaPago;
    }

    public void setFechaMaximaPago(String fechaMaximaPago) {
        this.fechaMaximaPago = fechaMaximaPago;
    }
    public static void registrarNuevaMulta(Multa multa) {
    // Implementar lógica para almacenar la multa
    // Por ejemplo, agregarla a una lista estática de multas
    // o guardarla en un archivo CSV
}

}
