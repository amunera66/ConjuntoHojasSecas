/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.conjunto.hojassecas;

import javax.swing.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Factura {
    private String numeroFactura;
    private String fecha;
    private String numeroPropiedad;
    private double valorTotal;
    private double valorMultas;
    private String fechaLimitePago;
    private double valorPagado;

    // Constructor
    public Factura(String numeroFactura, String fecha, String numeroPropiedad, double valorTotal, double valorMultas, String fechaLimitePago, double valorPagado) {
        this.numeroFactura = numeroFactura;
        this.fecha = fecha;
        this.numeroPropiedad = numeroPropiedad;
        this.valorTotal = valorTotal;
        this.valorMultas = valorMultas;
        this.fechaLimitePago = fechaLimitePago;
        this.valorPagado = valorPagado;
    }

    // Método para generar y guardar la factura en un archivo CSV
    public void generarFactura() {
        String csvFile = "facturas.csv"; // Nombre del archivo CSV

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(csvFile, true))) {
            writer.write(this.numeroFactura + "," + this.fecha + "," + this.numeroPropiedad + "," + this.valorTotal + "," + this.valorMultas + "," + this.fechaLimitePago + "," + this.valorPagado);
            writer.newLine();
            JOptionPane.showMessageDialog(null, "Factura generada exitosamente.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al generar la factura: " + e.getMessage());
        }
    }

    // Método para eliminar una factura
    public static void eliminarFactura(String numeroFactura) {
        String csvFile = "facturas.csv";
        try {
            List<String> lines = Files.readAllLines(Paths.get(csvFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(csvFile));

            boolean found = false;
            for (String line : lines) {
                String[] data = line.split(",");
                if (!data[0].equals(numeroFactura)) {
                    writer.write(line);
                    writer.newLine();
                } else {
                    found = true;
                }
            }
            writer.close();

            if (found) {
                JOptionPane.showMessageDialog(null, "Factura eliminada exitosamente.");
            } else {
                JOptionPane.showMessageDialog(null, "Factura no encontrada.");
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar la factura: " + e.getMessage());
        }
    }

    // Método para consultar facturas
    public static void consultarFacturas() {
        String csvFile = "facturas.csv";
        try {
            List<String> lines = Files.readAllLines(Paths.get(csvFile));
            StringBuilder sb = new StringBuilder("Lista de Facturas:\n");
            for (String line : lines) {
                sb.append(line).append("\n");
            }
            JOptionPane.showMessageDialog(null, sb.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al consultar las facturas: " + e.getMessage());
        }
    }
}


