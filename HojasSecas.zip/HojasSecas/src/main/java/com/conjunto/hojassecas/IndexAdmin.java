/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.conjunto.hojassecas;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class IndexAdmin extends JFrame {
    public IndexAdmin() {
        setTitle("Index Admin");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Cargar la imagen de fondo
        ImageIcon backgroundImage = new ImageIcon("src/main/resources/background.jpg");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        setContentPane(backgroundLabel);
        setLayout(null); // Usar layout nulo para posicionar manualmente

        JButton opcionesButton = new JButton("Opciones de Propietario");
        opcionesButton.setBounds(100, 100, 200, 30); // Ajustar posición y tamaño del botón
        opcionesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarOpcionesPropietario();
            }
        });

        JButton propiedadesButton = new JButton("Opciones de Propiedad");
        propiedadesButton.setBounds(100, 140, 200, 30); // Ajustar posición del botón de propiedades
        propiedadesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarOpcionesPropiedad();
            }
        });

        // Botón de Facturación
        JButton facturacionButton = new JButton("Facturación");
        facturacionButton.setBounds(100, 180, 200, 30);
        facturacionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarOpcionesFacturacion();
            }
        });

        add(opcionesButton);
        add(propiedadesButton);
        add(facturacionButton);
        setLocationRelativeTo(null); // Centrar la ventana
    }

    private void mostrarOpcionesFacturacion() {
        String[] opciones = {"Generar Factura", "Eliminar Factura", "Consultar Facturas"};
        String seleccion = (String) JOptionPane.showInputDialog(this, "Seleccione una opción:",
                "Opciones de Facturación", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

        if (seleccion != null) {
            switch (seleccion) {
                case "Generar Factura":
                    generarFactura();
                    break;

                case "Eliminar Factura":
                    String numeroFacturaEliminar = JOptionPane.showInputDialog(this, "Ingrese el número de factura a eliminar:");
                    Factura.eliminarFactura(numeroFacturaEliminar);
                    break;

                case "Consultar Facturas":
                    Factura.consultarFacturas();
                    break;
            }
        }
    }

    private void generarFactura() {
        String numeroFactura = JOptionPane.showInputDialog("Ingrese el número de factura:");
        String fecha = JOptionPane.showInputDialog("Ingrese la fecha:");
        String numeroPropiedad = JOptionPane.showInputDialog("Ingrese el número de propiedad:");
        double valorTotal = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el valor total:"));
        double valorMultas = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el valor de multas:"));
        String fechaLimitePago = JOptionPane.showInputDialog("Ingrese la fecha límite de pago:");
        double valorPagado = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el valor pagado:"));

        // Crear una nueva factura
        Factura nuevaFactura = new Factura(numeroFactura, fecha, numeroPropiedad, valorTotal, valorMultas, fechaLimitePago, valorPagado);
        nuevaFactura.generarFactura(); // Método para guardar la factura en CSV
    }

    private void mostrarOpcionesPropiedad() {
        String[] opciones = {"Agregar Propiedad", "Eliminar Propiedad", "Consultar Propiedades"};
        String seleccion = (String) JOptionPane.showInputDialog(this, "Seleccione una opción:",
                "Opciones de Propiedad", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

        if (seleccion != null) {
            switch (seleccion) {
                case "Agregar Propiedad":
                    String numeroCasa = JOptionPane.showInputDialog(this, "Ingrese el número de casa:");
                    double valorAdministracion = Double.parseDouble(JOptionPane.showInputDialog(this, "Ingrese el valor de administración:"));
                    double saldoActual = Double.parseDouble(JOptionPane.showInputDialog(this, "Ingrese el saldo actual:"));
                    double metrosCuadrados = Double.parseDouble(JOptionPane.showInputDialog(this, "Ingrese los metros cuadrados:"));

                    Propiedad nuevaPropiedad = new Propiedad(numeroCasa, valorAdministracion, saldoActual, metrosCuadrados);
                    Propiedad.agregarPropiedad(nuevaPropiedad);
                    break;

                case "Eliminar Propiedad":
                    String numeroCasaEliminar = JOptionPane.showInputDialog(this, "Ingrese el número de casa a eliminar:");
                    Propiedad.eliminarPropiedad(numeroCasaEliminar);
                    break;

                case "Consultar Propiedades":
                    Propiedad.consultarPropiedades();
                    break;
            }
        }
    }

   private void mostrarOpcionesPropietario() {
    String[] opciones = {"Agregar Propietario", "Eliminar Propietario", "Consultar Propietarios", "Registrar Multa"};
    String seleccion = (String) JOptionPane.showInputDialog(this, "Seleccione una opción:",
            "Opciones de Propietario", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

    if (seleccion != null) {
        switch (seleccion) {
            case "Agregar Propietario":
                // Llamar al método de agregar propietario
                Propietario.agregarPropietario();
                break;

            case "Eliminar Propietario":
                String idEliminar = JOptionPane.showInputDialog(this, "Ingrese el ID del propietario a eliminar:");
                Propietario.eliminarPropietario(idEliminar);
                break;

            case "Consultar Propietarios":
                Propietario.consultarPropietarios();
                break;

            case "Registrar Multa":
                registrarMulta(); // Método para registrar una nueva multa
                break;
        }
    }
}

private void registrarMulta() {
    String nombrePropietario = JOptionPane.showInputDialog(this, "Ingrese el nombre del propietario:");
    String numeroPropiedad = JOptionPane.showInputDialog(this, "Ingrese el número de propiedad:");

    // Aquí podrías agregar la lógica para crear la multa y actualizar el estado
    // Esto es solo un ejemplo, debes definir cómo deseas manejar la creación de multas
    Multa nuevaMulta = new Multa("M001", "2024-10-24", numeroPropiedad, nombrePropietario,
            "Descripción de la multa", 50.0, "2024-11-24");
    
    // Aquí puedes agregar la lógica para actualizar el estado en tu almacenamiento
    // Por ejemplo, guardarlo en una lista estática de multas o en un archivo
    // Puedes crear un método en la clase `Multa` para manejar esto.

    JOptionPane.showMessageDialog(this, "Multa registrada con éxito.");
}


    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                IndexAdmin indexAdmin = new IndexAdmin();
                indexAdmin.setVisible(true);
            }
        });
    }
}
