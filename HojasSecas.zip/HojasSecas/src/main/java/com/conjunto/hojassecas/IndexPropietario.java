/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.conjunto.hojassecas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class IndexPropietario extends JFrame {
    public IndexPropietario() {
        setTitle("Index Propietario");
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Cargar la imagen de fondo
        ImageIcon backgroundImage = new ImageIcon("src/main/resources/background.jpg");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        setContentPane(backgroundLabel);
        setLayout(new FlowLayout(FlowLayout.LEFT)); // Usar FlowLayout para alinear a la izquierda

        // Crear los botones con tamaños más grandes
        JButton facturaButton = new JButton("Factura");
        facturaButton.setPreferredSize(new Dimension(150, 40)); // Tamaño más grande
        facturaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarFactura();
            }
        });

        JButton saldoButton = new JButton("Saldo");
        saldoButton.setPreferredSize(new Dimension(150, 40)); // Tamaño más grande
        saldoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarSaldo();
            }
        });

        JButton multasButton = new JButton("Multas");
        multasButton.setPreferredSize(new Dimension(150, 40)); // Tamaño más grande
        multasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarMultas();
            }
        });

        // Añadir los botones al panel
        add(facturaButton);
        add(saldoButton);
        add(multasButton);

        setLocationRelativeTo(null); // Centrar la ventana
    }

    private void mostrarFactura() {
        String numeroFactura = JOptionPane.showInputDialog(this, "Ingrese el número de factura:");
        // Aquí deberías obtener la factura asociada al número ingresado
        String facturaDetalles = "Detalles de la factura para el número " + numeroFactura; // Simulación
        JOptionPane.showMessageDialog(this, facturaDetalles);
    }

    private void mostrarSaldo() {
        // Aquí deberías obtener el saldo asociado a la factura
        double saldo = 100.0; // Simulación
        JOptionPane.showMessageDialog(this, "El saldo actual es: " + saldo);
    }

    private void mostrarMultas() {
        // Aquí deberías verificar si hay multas asociadas al propietario
        boolean tieneMulta = false; // Simulación
        if (tieneMulta) {
            JOptionPane.showMessageDialog(this, "El propietario tiene multas pendientes.");
        } else {
            JOptionPane.showMessageDialog(this, "El propietario no tiene multas pendientes.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            IndexPropietario indexPropietario = new IndexPropietario();
            indexPropietario.setVisible(true);
        });
    }
}
