/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.conjunto.hojassecas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Login extends JFrame {
    private JTextField usuarioField;
    private JPasswordField passwordField;

    public Login() {
        setTitle("Inicio de Sesión");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Cargar la imagen de fondo
        Image backgroundImage = Toolkit.getDefaultToolkit().getImage("src/main/resources/background.jpg");
        BackgroundPanel backgroundPanel = new BackgroundPanel(backgroundImage);
        setContentPane(backgroundPanel);

        // Crear un panel para los campos y etiquetas
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setOpaque(false); // Hacer que el panel sea transparente
        panel.setBorder(BorderFactory.createTitledBorder("Inicio de Sesión")); // Agregar borde

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Espaciado entre componentes
        gbc.anchor = GridBagConstraints.LINE_END; // Alinear todo a la derecha

        // Configuración de las etiquetas y campos
        JLabel usuarioLabel = new JLabel("Usuario:");
        usuarioField = new JTextField(10); // Ancho más pequeño
        JLabel passwordLabel = new JLabel("Contraseña:");
        passwordField = new JPasswordField(10); // Ancho más pequeño
        
        JButton loginButton = new JButton("Iniciar Sesión");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                validarLogin(); // Método para validar el inicio de sesión
            }
        });

        JButton registroButton = new JButton("Registro");
        registroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Navegar a la ventana de registro
                Registro registro = new Registro();
                registro.setVisible(true);
                dispose(); // Cerrar la ventana de login
            }
        });

        // Añadir los componentes al panel con GridBagLayout
        gbc.gridx = 0; // Columna 0
        gbc.gridy = 0; // Fila 0
        panel.add(usuarioLabel, gbc);

        gbc.gridx = 1; // Columna 1
        gbc.gridy = 0; // Fila 0
        panel.add(usuarioField, gbc);

        gbc.gridx = 0; // Columna 0
        gbc.gridy = 1; // Fila 1
        panel.add(passwordLabel, gbc);

        gbc.gridx = 1; // Columna 1
        gbc.gridy = 1; // Fila 1
        panel.add(passwordField, gbc);

        // Añadir el botón de iniciar sesión
        gbc.gridx = 0; // Columna 0
        gbc.gridy = 2; // Fila 2
        gbc.gridwidth = 2; // Abarcar 2 columnas
        gbc.anchor = GridBagConstraints.LINE_END; // Alinear el botón a la derecha
        panel.add(loginButton, gbc);

        // Añadir el botón de registro
        gbc.gridx = 0; // Columna 0
        gbc.gridy = 3; // Fila 3
        panel.add(registroButton, gbc);

        // Añadir el panel al fondo
        backgroundPanel.add(panel, BorderLayout.EAST); // Colocar el panel a la derecha
        setLocationRelativeTo(null); // Centrar la ventana
    }

    private void validarLogin() {
        String usuario = usuarioField.getText();
        String password = new String(passwordField.getPassword());
        boolean validado = false;

        try (BufferedReader reader = new BufferedReader(new FileReader("usuarios.csv"))) {
            String line;
            // Saltar la cabecera
            reader.readLine(); 

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals(usuario) && parts[1].equals(password)) {
                    validado = true; // Usuario y contraseña válidos
                    break;
                }
            }

            if (validado) {
                // Verificar si el usuario es un número de 3 dígitos
                if (usuario.matches("\\d{3}")) {
                    IndexPropietario indexPropietario = new IndexPropietario(); // Ir a la clase IndexPropietario
                    indexPropietario.setVisible(true);
                } else {
                    IndexAdmin indexAdmin = new IndexAdmin(); // Ir a la clase IndexAdmin
                    indexAdmin.setVisible(true);
                }
                dispose(); // Cerrar la ventana de login
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos.");
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al validar el inicio de sesión: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Login login = new Login();
            login.setVisible(true);
        });
    }
}
