/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.conjunto.hojassecas;

import javax.swing.*;
import java.util.ArrayList;

public class Propiedad {
    private String numeroCasa;
    private double valorAdministracion;
    private double saldoActual;
    private double metrosCuadrados;

    // Lista para almacenar las propiedades
    private static ArrayList<Propiedad> listaPropiedades = new ArrayList<>();

    public Propiedad(String numeroCasa, double valorAdministracion, double saldoActual, double metrosCuadrados) {
        this.numeroCasa = numeroCasa;
        this.valorAdministracion = valorAdministracion;
        this.saldoActual = saldoActual;
        this.metrosCuadrados = metrosCuadrados;
    }

    // Método para obtener el número de casa
    public String getNumeroCasa() {
        return numeroCasa;
    }

    // Métodos para agregar, eliminar y consultar propiedades
    public static void agregarPropiedad(Propiedad propiedad) {
        listaPropiedades.add(propiedad);
        JOptionPane.showMessageDialog(null, "Propiedad agregada exitosamente.");
    }

    public static void eliminarPropiedad(String numeroCasa) {
        for (Propiedad propiedad : listaPropiedades) {
            if (propiedad.numeroCasa.equals(numeroCasa)) {
                listaPropiedades.remove(propiedad);
                JOptionPane.showMessageDialog(null, "Propiedad eliminada exitosamente.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Propiedad no encontrada.");
    }

    public static void consultarPropiedades() {
        StringBuilder sb = new StringBuilder("Lista de Propiedades:\n");
        for (Propiedad propiedad : listaPropiedades) {
            sb.append("Número de Casa: ").append(propiedad.numeroCasa)
              .append(", Valor Administración: ").append(propiedad.valorAdministracion)
              .append(", Saldo Actual: ").append(propiedad.saldoActual)
              .append(", Metros Cuadrados: ").append(propiedad.metrosCuadrados)
              .append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }
}
