/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.conjunto.hojassecas;

import javax.swing.*;
import java.util.ArrayList;

public class Propietario extends Persona {
    private String direccion;
    private String correoElectronico;
    private String profesion;

    // Lista para almacenar los propietarios
    private static ArrayList<Propietario> listaPropietarios = new ArrayList<>();

    public Propietario(String nombre, String id, String telefono, int edad, String direccion, String correoElectronico, String profesion) {
        super(nombre, id, telefono, edad);
        this.direccion = direccion;
        this.correoElectronico = correoElectronico;
        this.profesion = profesion;
    }

    public static void agregarPropietario() {
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del propietario:");
        String id = JOptionPane.showInputDialog("Ingrese el ID del propietario:");
        String telefono = JOptionPane.showInputDialog("Ingrese el teléfono del propietario:");
        int edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la edad del propietario:"));
        String direccion = JOptionPane.showInputDialog("Ingrese la dirección del propietario:");
        String correoElectronico = JOptionPane.showInputDialog("Ingrese el correo electrónico del propietario:");
        String profesion = JOptionPane.showInputDialog("Ingrese la profesión del propietario:");

        Propietario nuevoPropietario = new Propietario(nombre, id, telefono, edad, direccion, correoElectronico, profesion);
        listaPropietarios.add(nuevoPropietario);
        JOptionPane.showMessageDialog(null, "Propietario agregado exitosamente.");
    }

    public static void eliminarPropietario(String id) {
        for (Propietario propietario : listaPropietarios) {
            if (propietario.getId().equals(id)) {
                listaPropietarios.remove(propietario);
                JOptionPane.showMessageDialog(null, "Propietario eliminado exitosamente.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Propietario no encontrado.");
    }

    public static void consultarPropietarios() {
        StringBuilder sb = new StringBuilder("Lista de Propietarios:\n");
        for (Propietario propietario : listaPropietarios) {
            sb.append("Nombre: ").append(propietario.getNombre())
              .append(", ID: ").append(propietario.getId())
              .append(", Teléfono: ").append(propietario.getTelefono())
              .append(", Edad: ").append(propietario.getEdad())
              .append(", Dirección: ").append(propietario.direccion)
              .append(", Correo Electrónico: ").append(propietario.correoElectronico)
              .append(", Profesión: ").append(propietario.profesion)
              .append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }
}
