/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.conjunto.hojassecas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Registro extends JFrame {
    private JTextField usuarioField;
    private JPasswordField passwordField;
    private static final String CSV_FILE = "usuarios.csv"; // Nombre del archivo CSV

    public Registro() {
        setTitle("Registro de Usuario");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Cargar la imagen de fondo
        Image backgroundImage = Toolkit.getDefaultToolkit().getImage("src/main/resources/background.jpg");
        BackgroundPanel backgroundPanel = new BackgroundPanel(backgroundImage);
        setContentPane(backgroundPanel);

        // Crear un panel para los campos y etiquetas
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setOpaque(false); // Hacer que el panel sea transparente
        panel.setBorder(BorderFactory.createTitledBorder("Registro de Usuario")); // Agregar borde

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Espaciado entre componentes
        gbc.anchor = GridBagConstraints.LINE_END; // Alinear todo a la derecha

        // Configuración de las etiquetas y campos
        JLabel usuarioLabel = new JLabel("Usuario:");
        usuarioField = new JTextField(10); // Ancho más pequeño
        JLabel passwordLabel = new JLabel("Contraseña:");
        passwordField = new JPasswordField(10); // Ancho más pequeño
        
        JButton registrarButton = new JButton("Registrar");
        registrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarUsuario();
            }
        });

        JButton loginButton = new JButton("Iniciar Sesión");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Navegar a la ventana de login
                Login login = new Login();
                login.setVisible(true);
                dispose(); // Cerrar la ventana de registro
            }
        });

        // Añadir los componentes al panel con GridBagLayout
        gbc.gridx = 0; // Columna 0
        gbc.gridy = 0; // Fila 0
        panel.add(usuarioLabel, gbc);

        gbc.gridx = 1; // Columna 1
        gbc.gridy = 0; // Fila 0
        panel.add(usuarioField, gbc);

        gbc.gridx = 0; // Columna 0
        gbc.gridy = 1; // Fila 1
        panel.add(passwordLabel, gbc);

        gbc.gridx = 1; // Columna 1
        gbc.gridy = 1; // Fila 1
        panel.add(passwordField, gbc);

        // Añadir el botón de registrar
        gbc.gridx = 0; // Columna 0
        gbc.gridy = 2; // Fila 2
        gbc.gridwidth = 2; // Abarcar 2 columnas
        gbc.anchor = GridBagConstraints.LINE_END; // Alinear el botón a la derecha
        panel.add(registrarButton, gbc);

        // Añadir el botón de iniciar sesión
        gbc.gridx = 0; // Columna 0
        gbc.gridy = 3; // Fila 3
        panel.add(loginButton, gbc);

        // Añadir el panel al fondo
        backgroundPanel.add(panel, BorderLayout.EAST); // Colocar el panel a la derecha
        setLocationRelativeTo(null); // Centrar la ventana
    }

    private void registrarUsuario() {
        String usuario = usuarioField.getText();
        String password = new String(passwordField.getPassword());

        if (usuario.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
            return;
        }

        try {
            // Comprobar si el archivo CSV ya existe
            if (!Files.exists(Paths.get(CSV_FILE))) {
                // Si no existe, crear y escribir la cabecera
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(CSV_FILE))) {
                    writer.write("Usuario,Contraseña\n"); // Cabecera
                }
            }

            // Agregar el nuevo usuario al archivo CSV
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(CSV_FILE, true))) {
                writer.write(usuario + "," + password + "\n");
                JOptionPane.showMessageDialog(this, "Usuario registrado exitosamente.");
                usuarioField.setText("");
                passwordField.setText("");
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al registrar el usuario: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Registro registro = new Registro();
            registro.setVisible(true);
        });
    }
}
